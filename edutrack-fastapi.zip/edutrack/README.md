# EduTrack AI — frontend + backend FastAPI

Le backend Python (FastAPI) sert l'interface et fait office de **proxy IA sécurisé** : la clé API reste côté serveur, jamais dans le navigateur.

```
edutrack/
├── frontend/index.html      # ton site (assistant branché sur /api/chat)
├── backend/
│   ├── app/                 # main.py, ai_provider.py, demo_engine.py, rate_limit.py, schemas.py, prompts.py, config.py
│   ├── tests/
│   ├── requirements.txt
│   └── .env.example
└── Dockerfile
```

## Lancer en local

```bash
cd backend
python -m venv .venv && source .venv/bin/activate      # Windows : .venv\Scripts\activate
pip install -r requirements.txt
cp .env.example .env                                   # puis renseigne ANTHROPIC_API_KEY
uvicorn app.main:app --reload
```

Ouvre http://localhost:8000. Doc interactive de l'API : http://localhost:8000/api/docs.

- **Avec clé** : le badge de l'assistant indique « IA réelle activée » et chaque réponse affiche le modèle.
- **Sans clé** : « Mode démo — réponses locales, pas une vraie IA » (règles simples, résumé extractif, quiz à trous). Jamais présenté comme une vraie IA.

## API

| Route | Rôle |
|---|---|
| `GET /api/health` | `{status, ai_enabled, mode}` |
| `POST /api/chat` | `{messages:[{role,content}], mode, niveau?, matiere?}` → `{reply, source, model?}` |

`mode` : `chat`, `explain`, `summarize`, `quiz`, `memorize`. Limites : 20 messages, 4000 caractères par message, 15 requêtes/minute/IP (configurable). Erreurs en français : 422 (validation), 429 (débit), 502/503/504 (fournisseur IA).

## Variables d'environnement

Voir `backend/.env.example` (`ANTHROPIC_API_KEY`, `ANTHROPIC_MODEL`, `RATE_LIMIT_PER_MINUTE`, `AI_TIMEOUT_SECONDS`, `AI_MAX_TOKENS`, `CORS_ORIGINS`). Ne commite jamais `.env`.

## Déploiement (Render, Railway, Fly.io… via Docker)

1. Pousse le dossier sur GitHub.
2. Crée un service web à partir du `Dockerfile` à la racine.
3. Ajoute `ANTHROPIC_API_KEY` dans les variables d'environnement de la plateforme.
4. Déploie, puis teste `https://ton-domaine/api/health`.

Vercel/Netlify conviennent au frontend seul, pas à ce serveur FastAPI long-vivant : dans ce cas héberge le backend ailleurs, définis `window.EDUTRACK_API_BASE` dans le HTML et renseigne `CORS_ORIGINS`.

## Tests

```bash
python backend/tests/test_logic.py          # sans dépendance
pip install -r backend/requirements-dev.txt && cd backend && pytest   # + tests de l'API
```

## Checklist après déploiement

- [ ] `/api/health` répond `status: ok` et le bon `mode`
- [ ] Message envoyé dans chaque mode (Discuter, Expliquer, Résumer, Quiz, Mémoriser)
- [ ] Badge et étiquettes de source cohérents (IA réelle vs démo)
- [ ] Message de 5000 caractères refusé proprement ; 16 messages rapides → erreur 429 lisible
- [ ] Serveur coupé → message « Serveur injoignable », sans crash
- [ ] Actualisation : l'historique de conversation est conservé (localStorage, cet appareil uniquement)
- [ ] La clé n'apparaît nulle part dans le code source de la page (Ctrl+U)
