"""EduTrack AI — API FastAPI (proxy IA sécurisé + service du frontend statique)."""
import logging
from contextlib import asynccontextmanager
from pathlib import Path

import httpx
from fastapi import FastAPI, HTTPException, Request
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import JSONResponse
from fastapi.staticfiles import StaticFiles

from . import demo_engine
from .ai_provider import AIProviderError, generate_reply
from .config import get_settings
from .rate_limit import RateLimiter
from .schemas import ChatRequest, ChatResponse, HealthResponse

logger = logging.getLogger("edutrack")
settings = get_settings()
limiter = RateLimiter(settings.rate_limit_per_minute)
FRONTEND_DIR = Path(__file__).resolve().parent.parent.parent / "frontend"


@asynccontextmanager
async def lifespan(app: FastAPI):
    app.state.http = httpx.AsyncClient()
    yield
    await app.state.http.aclose()


app = FastAPI(title="EduTrack AI API", version="1.0.0", lifespan=lifespan, docs_url="/api/docs", openapi_url="/api/openapi.json")

if settings.cors_origins:
    app.add_middleware(
        CORSMiddleware,
        allow_origins=list(settings.cors_origins),
        allow_methods=["GET", "POST"],
        allow_headers=["Content-Type"],
    )


@app.middleware("http")
async def security_headers(request: Request, call_next):
    response = await call_next(request)
    response.headers.setdefault("X-Content-Type-Options", "nosniff")
    response.headers.setdefault("Referrer-Policy", "strict-origin-when-cross-origin")
    response.headers.setdefault("X-Frame-Options", "DENY")
    return response


def _client_key(request: Request) -> str:
    # Derrière un proxy (Render, Railway...), lance uvicorn avec --proxy-headers
    # pour que request.client.host reflète la vraie IP du visiteur.
    return request.client.host if request.client else "unknown"


@app.get("/api/health", response_model=HealthResponse)
async def health() -> HealthResponse:
    return HealthResponse(status="ok", ai_enabled=settings.ai_enabled, mode="ai" if settings.ai_enabled else "demo")


@app.post("/api/chat", response_model=ChatResponse)
async def chat(req: ChatRequest, request: Request) -> ChatResponse:
    key = _client_key(request)
    if not limiter.allow(key):
        wait = limiter.retry_after(key)
        raise HTTPException(
            status_code=429,
            detail=f"Trop de messages en peu de temps. Réessaie dans {wait} s.",
            headers={"Retry-After": str(wait)},
        )

    if not settings.ai_enabled:
        return ChatResponse(reply=demo_engine.reply(req), source="demo")

    try:
        text = await generate_reply(req, settings, request.app.state.http)
    except AIProviderError as exc:
        logger.warning("Erreur fournisseur IA (%s): %s", exc.status, exc.message)
        raise HTTPException(status_code=exc.status, detail=exc.message)
    return ChatResponse(reply=text, source="ai", model=settings.model)


@app.exception_handler(Exception)
async def unhandled(request: Request, exc: Exception):
    logger.exception("Erreur inattendue")
    return JSONResponse(status_code=500, content={"detail": "Une erreur inattendue est survenue. Réessaie plus tard."})


# Doit rester en dernier : sert le frontend sur "/" sans masquer /api/*
if FRONTEND_DIR.is_dir():
    app.mount("/", StaticFiles(directory=FRONTEND_DIR, html=True), name="frontend")
