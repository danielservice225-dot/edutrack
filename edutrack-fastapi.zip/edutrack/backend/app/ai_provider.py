"""Appel à l'API Anthropic Messages. La clé ne quitte jamais le serveur."""
import httpx

from .config import Settings
from .prompts import build_system_prompt
from .schemas import ChatRequest

ANTHROPIC_URL = "https://api.anthropic.com/v1/messages"
ANTHROPIC_VERSION = "2023-06-01"


class AIProviderError(Exception):
    """Erreur côté fournisseur d'IA ; `status` est le code HTTP à renvoyer au client."""

    def __init__(self, message: str, status: int = 502):
        super().__init__(message)
        self.message = message
        self.status = status


async def generate_reply(req: ChatRequest, settings: Settings, client: httpx.AsyncClient) -> str:
    payload = {
        "model": settings.model,
        "max_tokens": settings.max_tokens,
        "system": build_system_prompt(req.mode, req.niveau, req.matiere),
        "messages": [{"role": m.role, "content": m.content} for m in req.messages],
    }
    headers = {
        "x-api-key": settings.api_key,
        "anthropic-version": ANTHROPIC_VERSION,
        "content-type": "application/json",
    }
    try:
        resp = await client.post(ANTHROPIC_URL, json=payload, headers=headers, timeout=settings.timeout_seconds)
    except httpx.TimeoutException:
        raise AIProviderError("L'IA met trop de temps à répondre. Réessaie dans un instant.", 504)
    except httpx.HTTPError:
        raise AIProviderError("Impossible de joindre le service d'IA. Vérifie ta connexion et réessaie.", 502)

    if resp.status_code == 401:
        raise AIProviderError("La clé API configurée côté serveur est invalide.", 502)
    if resp.status_code == 429:
        raise AIProviderError("Le service d'IA est très sollicité. Réessaie dans quelques secondes.", 503)
    if resp.status_code >= 400:
        raise AIProviderError("Le service d'IA a renvoyé une erreur. Réessaie plus tard.", 502)

    try:
        blocks = resp.json().get("content", [])
        text = "".join(b.get("text", "") for b in blocks if b.get("type") == "text").strip()
    except ValueError:
        raise AIProviderError("Réponse illisible du service d'IA.", 502)
    if not text:
        raise AIProviderError("Le service d'IA n'a renvoyé aucune réponse.", 502)
    return text
