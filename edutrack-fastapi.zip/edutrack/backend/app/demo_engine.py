"""Moteur de démonstration LOCAL (règles simples, pas une IA).

Utilisé uniquement quand aucune clé API n'est configurée. L'interface étiquette
toujours ces réponses comme « mode démo ».
"""
import re
from collections import Counter
from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from .schemas import ChatRequest

_STOPWORDS = set(
    "le la les un une des du de d l et ou mais donc or ni car que qui quoi dont où ce cet cette ces se sa son ses "
    "leur leurs il elle ils elles on nous vous je tu me te lui y en à au aux par pour sur sous dans avec sans "
    "est sont été être a ont avoir fait faire plus très aussi comme si ne pas n s c qu j m t".split()
)

TOPICS = [
    (("dériv", "deriv"), """**Les dérivées en bref**

- La dérivée f'(x) donne la pente de la tangente à la courbe au point x.
- (xⁿ)' = n·xⁿ⁻¹ et (k)' = 0 pour une constante k.
- (f + g)' = f' + g' ; (f × g)' = f'g + fg'.

**Exemple :** f(x) = 3x² + 2x − 5, donc f'(x) = 6x + 2.

À toi : dérive g(x) = 4x³ − x. Dis-moi ce que tu trouves !"""),
    (("dissertation", "philo", "bonheur"), """**Méthode de la dissertation**

- **Introduction** : accroche, définition des termes, problématique, annonce du plan.
- **Développement** : 2 à 3 parties, chacune avec des arguments et des exemples précis.
- **Conclusion** : bilan, réponse à la problématique, ouverture.

Commence par définir chaque mot du sujet : c'est là que naît la problématique."""),
    (("physique", "chimie", "oxydo"), """**Méthode en physique-chimie**

- Relis le cours et note les formules avec leurs unités.
- Commence par les exercices d'application directe, puis passe aux problèmes complexes.
- Vérifie toujours l'homogénéité des unités à la fin.

Quelle notion veux-tu travailler ?"""),
]

MEMORIZE_TIPS = """**Techniques pour mieux mémoriser**

- **Rappel actif** : ferme ton cours et essaie d'écrire ce dont tu te souviens.
- **Répétition espacée** : relis à J+1, J+3, J+7 plutôt que tout d'un coup.
- **Explique à voix haute** comme si tu enseignais à quelqu'un.
- **Cartes mentales** pour relier les notions entre elles.
- **Sessions courtes** de 25 minutes avec 5 minutes de pause."""


def _sentences(text: str) -> list[str]:
    parts = re.split(r"(?<=[.!?])\s+|\n+", text.strip())
    return [p.strip() for p in parts if len(p.strip().split()) >= 4]


def _words(text: str) -> list[str]:
    return [w for w in re.findall(r"[A-Za-zÀ-ÿ'-]{3,}", text.lower()) if w not in _STOPWORDS]


def extractive_summary(text: str, max_sentences: int = 4) -> str:
    sents = _sentences(text)
    if len(sents) < 2:
        return ""
    freq = Counter(_words(text))
    scored = []
    for i, s in enumerate(sents):
        ws = _words(s)
        score = sum(freq[w] for w in ws) / (len(ws) or 1)
        scored.append((score, i, s))
    best = sorted(scored, reverse=True)[:max_sentences]
    ordered = [s for _, _, s in sorted(best, key=lambda t: t[1])]
    return "\n".join(f"- {s}" for s in ordered)


def cloze_quiz(text: str, n: int = 4) -> str:
    sents = _sentences(text)
    freq = Counter(_words(text))
    questions = []
    for s in sents:
        candidates = [w for w in _words(s) if len(w) >= 5]
        if not candidates:
            continue
        key = max(candidates, key=lambda w: freq[w])
        blank = re.sub(re.escape(key), "_____", s, count=1, flags=re.IGNORECASE)
        questions.append((blank, key))
        if len(questions) == n:
            break
    if not questions:
        return ""
    lines = ["**Quiz à trous** (généré à partir de ton texte)", ""]
    lines += [f"{i}. {q}" for i, (q, _) in enumerate(questions, 1)]
    lines += ["", "**Corrigé**", ""]
    lines += [f"{i}. {a}" for i, (_, a) in enumerate(questions, 1)]
    return "\n".join(lines)


def reply(req: "ChatRequest") -> str:
    text = req.messages[-1].content
    low = text.lower()

    if req.mode == "summarize":
        out = extractive_summary(text)
        if out:
            return "**Résumé (extraction des phrases clés)**\n\n" + out
        return "Colle un texte d'au moins quelques phrases pour que je puisse en extraire l'essentiel."

    if req.mode == "quiz":
        out = cloze_quiz(text)
        if out:
            return out
        return "Pour créer un quiz en mode démo, colle le texte de ton cours (au moins quelques phrases)."

    if req.mode == "memorize":
        return MEMORIZE_TIPS

    for keys, answer in TOPICS:
        if any(k in low for k in keys):
            return answer

    return (
        "En mode démo, je ne connais que quelques sujets (dérivées, dissertation, physique-chimie) "
        "et je peux résumer un texte, faire un quiz à trous ou donner des méthodes de mémorisation.\n\n"
        "Pour répondre à n'importe quelle question, il faut activer l'IA réelle en configurant une clé API côté serveur."
    )
