"""Modèles de validation des requêtes/réponses."""
from typing import Literal, Optional

from pydantic import BaseModel, Field, field_validator

MAX_MESSAGES = 20
MAX_CONTENT_CHARS = 4000

Mode = Literal["chat", "explain", "summarize", "quiz", "memorize"]


class ChatMessage(BaseModel):
    role: Literal["user", "assistant"]
    content: str = Field(min_length=1, max_length=MAX_CONTENT_CHARS)

    @field_validator("content")
    @classmethod
    def not_blank(cls, v: str) -> str:
        if not v.strip():
            raise ValueError("Le message ne peut pas être vide.")
        return v


class ChatRequest(BaseModel):
    messages: list[ChatMessage] = Field(min_length=1, max_length=MAX_MESSAGES)
    mode: Mode = "chat"
    niveau: Optional[str] = Field(default=None, max_length=40)
    matiere: Optional[str] = Field(default=None, max_length=60)

    @field_validator("messages")
    @classmethod
    def last_is_user(cls, v: list[ChatMessage]) -> list[ChatMessage]:
        if v[-1].role != "user":
            raise ValueError("Le dernier message doit venir de l'élève.")
        return v


class ChatResponse(BaseModel):
    reply: str
    source: Literal["ai", "demo"]
    model: Optional[str] = None


class HealthResponse(BaseModel):
    status: Literal["ok"]
    ai_enabled: bool
    mode: Literal["ai", "demo"]
