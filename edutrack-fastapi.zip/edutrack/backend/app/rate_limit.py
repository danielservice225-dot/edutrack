"""Limiteur de débit simple en mémoire (fenêtre glissante, par clé)."""
import time
from collections import defaultdict, deque
from typing import Callable, Deque, Dict


class RateLimiter:
    def __init__(self, max_calls: int, period: float = 60.0, clock: Callable[[], float] = time.monotonic):
        self.max_calls = max_calls
        self.period = period
        self._clock = clock
        self._hits: Dict[str, Deque[float]] = defaultdict(deque)

    def allow(self, key: str) -> bool:
        now = self._clock()
        hits = self._hits[key]
        while hits and now - hits[0] >= self.period:
            hits.popleft()
        if len(hits) >= self.max_calls:
            return False
        hits.append(now)
        return True

    def retry_after(self, key: str) -> int:
        hits = self._hits.get(key)
        if not hits:
            return 0
        return max(1, int(self.period - (self._clock() - hits[0])) + 1)
