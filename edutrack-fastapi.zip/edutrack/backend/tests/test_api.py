"""Tests de l'API (nécessitent fastapi + httpx installés : pip install -r requirements-dev.txt)."""
import pytest

pytest.importorskip("fastapi")
pytest.importorskip("httpx")

from fastapi.testclient import TestClient  # noqa: E402

from app.main import app, limiter  # noqa: E402


@pytest.fixture(autouse=True)
def reset_limiter():
    limiter._hits.clear()


def test_health_reports_mode():
    with TestClient(app) as c:
        data = c.get("/api/health").json()
    assert data["status"] == "ok" and data["mode"] in ("ai", "demo")


def test_demo_chat_labels_source(monkeypatch):
    import app.main as m
    monkeypatch.setattr(m, "settings", type("S", (), {"ai_enabled": False})())
    with TestClient(app) as c:
        r = c.post("/api/chat", json={"messages": [{"role": "user", "content": "dérivées"}]})
    assert r.status_code == 200 and r.json()["source"] == "demo"


def test_rejects_invalid_payloads():
    with TestClient(app) as c:
        assert c.post("/api/chat", json={"messages": []}).status_code == 422
        assert c.post("/api/chat", json={"messages": [{"role": "assistant", "content": "x"}]}).status_code == 422
        assert c.post("/api/chat", json={"messages": [{"role": "user", "content": "x" * 5000}]}).status_code == 422


def test_rate_limit(monkeypatch):
    import app.main as m
    monkeypatch.setattr(m, "settings", type("S", (), {"ai_enabled": False})())
    monkeypatch.setattr(m, "limiter", type(limiter)(2))
    body = {"messages": [{"role": "user", "content": "dérivées"}]}
    with TestClient(app) as c:
        assert c.post("/api/chat", json=body).status_code == 200
        assert c.post("/api/chat", json=body).status_code == 200
        assert c.post("/api/chat", json=body).status_code == 429
