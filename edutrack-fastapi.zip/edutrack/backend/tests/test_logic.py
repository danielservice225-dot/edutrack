"""Tests de la logique pure (sans FastAPI) : moteur démo et limiteur de débit."""
import sys
import unittest
from pathlib import Path
from types import SimpleNamespace

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

from app import demo_engine  # noqa: E402
from app.rate_limit import RateLimiter  # noqa: E402

COURS = (
    "La photosynthèse est le processus par lequel les plantes produisent de la matière organique. "
    "Elle se déroule dans les chloroplastes, qui contiennent la chlorophylle. "
    "La chlorophylle absorbe la lumière du soleil pour fabriquer du glucose à partir du dioxyde de carbone. "
    "Le glucose produit par la photosynthèse sert ensuite de réserve d'énergie à la plante."
)


def req(text, mode="chat"):
    return SimpleNamespace(mode=mode, messages=[SimpleNamespace(role="user", content=text)])


class DemoEngineTests(unittest.TestCase):
    def test_topic_rule(self):
        self.assertIn("pente de la tangente", demo_engine.reply(req("Explique-moi les dérivées")))

    def test_unknown_question_is_honest(self):
        out = demo_engine.reply(req("Qui a gagné la bataille de Marignan ?"))
        self.assertIn("clé API", out)

    def test_summary_is_extractive(self):
        out = demo_engine.reply(req(COURS, "summarize"))
        self.assertTrue(out.startswith("**Résumé"))
        for line in out.splitlines():
            if line.startswith("- "):
                self.assertIn(line[2:], COURS)

    def test_summary_needs_text(self):
        self.assertIn("Colle un texte", demo_engine.reply(req("bonjour", "summarize")))

    def test_quiz_has_answers_from_text(self):
        out = demo_engine.reply(req(COURS, "quiz"))
        self.assertIn("_____", out)
        self.assertIn("Corrigé", out)
        answers = out.split("**Corrigé**")[1].strip().splitlines()
        for a in filter(None, answers):
            self.assertIn(a.split(". ", 1)[1].lower(), COURS.lower())

    def test_memorize(self):
        self.assertIn("Répétition espacée", demo_engine.reply(req("aide", "memorize")))


class RateLimiterTests(unittest.TestCase):
    def test_blocks_then_recovers(self):
        t = [0.0]
        rl = RateLimiter(2, 60, clock=lambda: t[0])
        self.assertTrue(rl.allow("a"))
        self.assertTrue(rl.allow("a"))
        self.assertFalse(rl.allow("a"))
        self.assertGreaterEqual(rl.retry_after("a"), 1)
        self.assertTrue(rl.allow("b"))  # autre clé indépendante
        t[0] = 61.0
        self.assertTrue(rl.allow("a"))


if __name__ == "__main__":
    unittest.main()
